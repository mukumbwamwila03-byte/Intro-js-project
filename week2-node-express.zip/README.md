
# Week 2 Node Express API

## Setup
npm install
npm start

## Routes
GET / -> My Week 2 API
POST /user -> Accepts name, email
GET /user/:id -> User profile

## Bonus
Custom middleware logs requests
