
require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Custom middleware (bonus)
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});

// JSON parsing
app.use(express.json());

// Serve static HTML
app.use(express.static(path.join(__dirname, 'public')));

// GET /
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// POST /user
app.post('/user', (req, res) => {
    const { name, email } = req.body;

    if (!name || !email) {
        return res.status(400).json({ error: 'Name and email are required' });
    }

    res.json({ message: `Hello, ${name}!` });
});

// GET /user/:id
app.get('/user/:id', (req, res) => {
    const userId = req.params.id;
    res.json({ message: `User ${userId} profile` });
});

// Error handling
app.use((err, req, res, next) => {
    res.status(500).json({ error: 'Something went wrong' });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
