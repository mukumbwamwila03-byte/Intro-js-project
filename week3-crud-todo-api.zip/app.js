
const express = require('express');
const app = express();

app.use(express.json());

let todos = [];
let idCounter = 1;

// CREATE todo
app.post('/todos', (req, res) => {
    const { task, completed } = req.body;

    if (!task) {
        return res.status(400).json({ error: 'Task field is required' });
    }

    const newTodo = {
        id: idCounter++,
        task,
        completed: completed || false
    };

    todos.push(newTodo);
    res.status(201).json(newTodo);
});

// READ all todos
app.get('/todos', (req, res) => {
    res.json(todos);
});

// READ single todo
app.get('/todos/:id', (req, res) => {
    const todo = todos.find(t => t.id === parseInt(req.params.id));
    if (!todo) {
        return res.status(404).json({ error: 'Todo not found' });
    }
    res.json(todo);
});

// BONUS: get active todos (not completed)
app.get('/todos/active', (req, res) => {
    const activeTodos = todos.filter(t => !t.completed);
    res.json(activeTodos);
});

// UPDATE todo
app.put('/todos/:id', (req, res) => {
    const todo = todos.find(t => t.id === parseInt(req.params.id));
    if (!todo) {
        return res.status(404).json({ error: 'Todo not found' });
    }

    const { task, completed } = req.body;
    if (task !== undefined) todo.task = task;
    if (completed !== undefined) todo.completed = completed;

    res.json(todo);
});

// DELETE todo
app.delete('/todos/:id', (req, res) => {
    const index = todos.findIndex(t => t.id === parseInt(req.params.id));
    if (index === -1) {
        return res.status(404).json({ error: 'Todo not found' });
    }

    todos.splice(index, 1);
    res.json({ message: 'Todo deleted successfully' });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Todo API running on port ${PORT}`);
});
