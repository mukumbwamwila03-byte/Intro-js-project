
# Week 3 CRUD Todo API

## How to Run
1. Install Node.js
2. Run: npm install
3. Start server: npm start

## API Routes

POST /todos  
- Requires: task

GET /todos  
- Get all todos

GET /todos/:id  
- Get single todo

GET /todos/active  
- Get all active (not completed) todos

PUT /todos/:id  
- Update task or completed status

DELETE /todos/:id  
- Delete todo
